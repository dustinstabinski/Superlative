# Please do not tamper with the information below
APP_ID     = '1510417525693226' 
APP_SECRET = '2676d6c72dc6ab83535a83c231a0a150' 

